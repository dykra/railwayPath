CREATE PROCEDURE dbo.SDE_registry_def_change_table_name       @tabNameVal sysname, @regIdVal INTEGER AS SET NOCOUNT ON
      UPDATE m set m.object_name = @tabNameVal from LosAngelesCounty.dbo.SDE_metadata m 
       INNER JOIN LosAngelesCounty.dbo.SDE_table_registry r ON 
       m.object_database = r.database_name AND m.object_name = r.table_name AND 
       m.object_owner = r.owner 
       WHERE  r.registration_id = @regIdVal AND m.object_type = 1 
      UPDATE LosAngelesCounty.dbo.SDE_table_registry SET table_name = @tabNameVal WHERE registration_id = @regIdVal
go

