CREATE FUNCTION dbo.retrieve_guid () RETURNS NVARCHAR(38)
BEGIN
  RETURN(SELECT guidstr from LosAngelesCounty.dbo.SDE_generate_guid )
END
go

