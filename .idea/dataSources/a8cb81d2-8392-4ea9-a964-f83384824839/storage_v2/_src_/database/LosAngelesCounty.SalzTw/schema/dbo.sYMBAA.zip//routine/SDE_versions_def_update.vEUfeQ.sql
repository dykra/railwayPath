CREATE PROCEDURE dbo.SDE_versions_def_update        @statusVal INTEGER, @descVal NVARCHAR(64), @nameVal NVARCHAR(64),        @ownerVal NVARCHAR(32) AS SET NOCOUNT ON UPDATE LosAngelesCounty.dbo.SDE_versions SET status = @statusVal,        description = @descVal WHERE name = @nameVal and owner = @ownerVal
go

