CREATE PROCEDURE dbo.SDE_dbtune_def_update       @keywordVal NVARCHAR(32),@parameter_nameVal NVARCHAR(32),       @config_stringVal NVARCHAR(2048) AS UPDATE LosAngelesCounty.dbo.SDE_dbtune       SET  config_string = @config_stringVal WHERE       keyword = @keywordVal AND parameter_name = @parameter_nameVal
go

