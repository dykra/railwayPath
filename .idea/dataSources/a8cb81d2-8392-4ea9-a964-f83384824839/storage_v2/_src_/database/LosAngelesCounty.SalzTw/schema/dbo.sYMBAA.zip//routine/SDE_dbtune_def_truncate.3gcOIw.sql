CREATE PROCEDURE dbo.SDE_dbtune_def_truncate       AS SET NOCOUNT ON DELETE FROM LosAngelesCounty.dbo.SDE_dbtune
go

