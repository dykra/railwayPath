CREATE PROCEDURE dbo.SDE_layer_def_change_table_name              @tabNameVal sysname, @layerIdVal INTEGER AS SET NOCOUNT ON             UPDATE LosAngelesCounty.dbo.SDE_layers SET              table_name = @tabNameVal  WHERE layer_id = @layerIdVal
go

