CREATE PROCEDURE dbo.gdb_util_release AS SELECT 3
go

