CREATE VIEW dbo.SDE_generate_guid AS 
 SELECT '{' + CONVERT(NVARCHAR(36),newid()) + '}' as guidstr
go

