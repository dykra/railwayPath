CREATE TRIGGER DBO.v31_update  ON LOSANGELESCOUNTY.DBO.LACountyBoundary_evw INSTEAD OF UPDATE AS 
BEGIN
IF @@rowcount = 0 RETURN
DECLARE @current_state BIGINT
DECLARE @ret INTEGER
-- Check if we are already in an edit session.
DECLARE @g_state_id BIGINT
DECLARE @g_protected CHAR(1)
DECLARE @g_is_default CHAR(1)
DECLARE @g_version_id INTEGER
DECLARE @state_is_set INTEGER
EXECUTE LosAngelesCounty.dbo.SDE_get_globals @g_state_id OUTPUT,@g_protected OUTPUT,@g_is_default OUTPUT,@g_version_id OUTPUT,@state_is_set OUTPUT
IF (@g_version_id = -1) AND (@g_is_default = '0')
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END

IF (@g_version_id = -1) AND (@g_is_default = '1') AND (@state_is_set = 1)
BEGIN
  RAISERROR ('Cannot call set_current_version before editing default version. Call set_default before editing.',16,-1)
  RETURN
END

IF @g_version_id = -1
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END
IF @g_version_id != -1  -- standard editing
BEGIN
  EXECUTE @ret = LosAngelesCounty.dbo.SDE_current_version_writable @current_state OUTPUT
  IF @ret <> 0 RETURN
END
ELSE -- default version editing
  SET @current_state = @g_state_id
DECLARE @new_state BIGINT
DECLARE @current_lineage BIGINT
DECLARE @edit_cnt INTEGER
DECLARE @error_string NVARCHAR(256)

SELECT @current_lineage = lineage_name  FROM LosAngelesCounty.dbo.SDE_states
  WHERE state_id = @current_state
IF UPDATE(OBJECTID)
BEGIN
  DECLARE @row_count INTEGER
  SELECT @row_count = COUNT(*) FROM deleted
  IF @row_count > 1 OR (SELECT COUNT(*) FROM inserted i INNER JOIN deleted d
  ON i.OBJECTID = d.OBJECTID) != @row_count
  BEGIN
    RAISERROR ('Attempted update of SDE row id column.',16,-1)
    RETURN
  END
END
DECLARE @new_row_id INTEGER
DECLARE @old_row_id INTEGER
DECLARE @old_state_id BIGINT
DECLARE @new_spatial_column geometry
DECLARE @old_spatial_column geometry
DECLARE updt_cursor CURSOR FOR SELECT d.OBJECTID,d.SDE_STATE_ID,i.SHAPE,d.SHAPE,
 i.OBJECTID,
 i.CITY,
 i.CITY_ID,
 i.CITY_TYPE,
 i.CITY_NAME,
 i.CITY_LABEL,
 i.COLOR_CODE,
 i.ABBR,
 i.CITY_NO,
 i.DESCRIPTN,
 i.URL,
 i.PHONE,
 i.OF_AREA_SM,
 i.FEAT_TYPE,
 i.COMMENT,
 i.SUB_TYPE,
 i.COLOR,
 i.SQMI,
 i.County
  FROM inserted i INNER JOIN deleted d
  ON i.OBJECTID = d.OBJECTID
DECLARE @upd_OBJECTID int
DECLARE @upd_CITY int
DECLARE @upd_CITY_ID int
DECLARE @upd_CITY_TYPE nvarchar(25) 
DECLARE @upd_CITY_NAME nvarchar(25) 
DECLARE @upd_CITY_LABEL nvarchar(21) 
DECLARE @upd_COLOR_CODE smallint
DECLARE @upd_ABBR nvarchar(4) 
DECLARE @upd_CITY_NO smallint
DECLARE @upd_DESCRIPTN nvarchar(8) 
DECLARE @upd_URL nvarchar(50) 
DECLARE @upd_PHONE nvarchar(50) 
DECLARE @upd_OF_AREA_SM numeric(18,8) 
DECLARE @upd_FEAT_TYPE nvarchar(16) 
DECLARE @upd_COMMENT nvarchar(50) 
DECLARE @upd_SUB_TYPE smallint
DECLARE @upd_COLOR nvarchar(16) 
DECLARE @upd_SQMI numeric(38,8) 
DECLARE @upd_County nvarchar(50) 
OPEN updt_cursor
FETCH NEXT FROM updt_cursor INTO @old_row_id, @old_state_id, @new_spatial_column, @old_spatial_column, @upd_OBJECTID, @upd_CITY, @upd_CITY_ID, @upd_CITY_TYPE, @upd_CITY_NAME, @upd_CITY_LABEL, @upd_COLOR_CODE, @upd_ABBR, @upd_CITY_NO, @upd_DESCRIPTN, @upd_URL, @upd_PHONE, @upd_OF_AREA_SM, @upd_FEAT_TYPE, @upd_COMMENT, @upd_SUB_TYPE, @upd_COLOR, @upd_SQMI, @upd_County
WHILE @@FETCH_STATUS = 0
BEGIN
  IF @g_is_default = '0'
  BEGIN
    IF (@old_state_id != @current_state)
    BEGIN
     INSERT INTO LOSANGELESCOUNTY.DBO.a31 (
OBJECTID,CITY,CITY_ID,CITY_TYPE,CITY_NAME,CITY_LABEL,COLOR_CODE,ABBR,CITY_NO,DESCRIPTN,URL,PHONE,OF_AREA_SM,FEAT_TYPE,COMMENT,SUB_TYPE,COLOR,SQMI,Shape,County,SDE_STATE_ID)
        VALUES(  @upd_OBJECTID, @upd_CITY, @upd_CITY_ID, @upd_CITY_TYPE, @upd_CITY_NAME, @upd_CITY_LABEL, @upd_COLOR_CODE, @upd_ABBR, @upd_CITY_NO, @upd_DESCRIPTN, @upd_URL, @upd_PHONE, @upd_OF_AREA_SM, @upd_FEAT_TYPE, @upd_COMMENT, @upd_SUB_TYPE, @upd_COLOR, @upd_SQMI, @new_spatial_column, @upd_County, @current_state)

     INSERT INTO LOSANGELESCOUNTY.DBO.d31 VALUES (@old_state_id, @old_row_id, @current_state)
     IF @old_spatial_column IS NOT NULL
     BEGIN
       IF NOT UPDATE(SHAPE)
         INSERT INTO LOSANGELESCOUNTY.DBO.SDE_GEOMETRY26 (GEOMETRY_ID, CAD, SDE_STATE_ID) SELECT GEOMETRY_ID, 
 CAD, @current_state FROM LOSANGELESCOUNTY.DBO.SDE_GEOMETRY26 WHERE GEOMETRY_ID = @old_row_id and SDE_STATE_ID = @old_state_id
     END
    END
    ELSE
    BEGIN
     UPDATE LOSANGELESCOUNTY.DBO.a31 SET CITY = @upd_CITY,CITY_ID = @upd_CITY_ID,CITY_TYPE = @upd_CITY_TYPE,CITY_NAME = @upd_CITY_NAME,CITY_LABEL = @upd_CITY_LABEL,COLOR_CODE = @upd_COLOR_CODE,ABBR = @upd_ABBR,CITY_NO = @upd_CITY_NO,DESCRIPTN = @upd_DESCRIPTN,URL = @upd_URL,PHONE = @upd_PHONE,OF_AREA_SM = @upd_OF_AREA_SM,FEAT_TYPE = @upd_FEAT_TYPE,COMMENT = @upd_COMMENT,SUB_TYPE = @upd_SUB_TYPE,COLOR = @upd_COLOR,SQMI = @upd_SQMI,Shape = @new_spatial_column,County = @upd_County 
WHERE OBJECTID = @old_row_id  AND SDE_STATE_ID = @current_state
     IF @old_spatial_column IS NOT NULL
     BEGIN
       IF UPDATE(SHAPE) 
         DELETE FROM LOSANGELESCOUNTY.DBO.SDE_GEOMETRY26 WHERE GEOMETRY_ID = @old_row_id  AND SDE_STATE_ID = @current_state
     END
    END
  END
FETCH NEXT FROM updt_cursor INTO @old_row_id, @old_state_id, @new_spatial_column, @old_spatial_column, @upd_OBJECTID, @upd_CITY, @upd_CITY_ID, @upd_CITY_TYPE, @upd_CITY_NAME, @upd_CITY_LABEL, @upd_COLOR_CODE, @upd_ABBR, @upd_CITY_NO, @upd_DESCRIPTN, @upd_URL, @upd_PHONE, @upd_OF_AREA_SM, @upd_FEAT_TYPE, @upd_COMMENT, @upd_SUB_TYPE, @upd_COLOR, @upd_SQMI, @upd_County
END
CLOSE updt_cursor
DEALLOCATE updt_cursor
IF (SELECT COUNT (*) FROM LosAngelesCounty.dbo.SDE_mvtables_modified WHERE state_id = @current_state AND registration_id = 31) = 0
 AND @current_state > 0
  EXECUTE LosAngelesCounty.dbo.SDE_mvmodified_table_insert 31, @current_state
END
go

