CREATE PROCEDURE dbo.SDE_xml_columns_def_delete
@columnIdVal INTEGER AS SET NOCOUNT ON
BEGIN
DELETE FROM LosAngelesCounty.dbo.SDE_xml_columns WHERE column_id =  @columnIdVal
END
go

