CREATE PROCEDURE dbo.SDE_xml_indexes_def_update
@index_id INTEGER, @indexNameVal NVARCHAR(32),
@descriptionVal NVARCHAR(64)
AS SET NOCOUNT ON
BEGIN
  UPDATE LosAngelesCounty.dbo.SDE_xml_indexes
   SET index_name = @indexNameVal, description = @descriptionVal
   WHERE index_id = @index_id
END
go

