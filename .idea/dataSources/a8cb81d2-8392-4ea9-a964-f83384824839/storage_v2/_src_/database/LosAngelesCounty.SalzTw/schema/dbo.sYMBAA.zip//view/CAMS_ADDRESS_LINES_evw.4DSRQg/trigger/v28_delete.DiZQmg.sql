CREATE TRIGGER DBO.v28_delete  ON LOSANGELESCOUNTY.DBO.CAMS_ADDRESS_LINES_evw INSTEAD OF DELETE AS 
BEGIN
IF @@rowcount = 0 RETURN
DECLARE @ret INTEGER
DECLARE @current_state BIGINT
-- Check if we are already in an edit session.
DECLARE @g_state_id BIGINT
DECLARE @g_protected CHAR(1)
DECLARE @g_is_default CHAR(1)
DECLARE @g_version_id INTEGER
DECLARE @state_is_set INTEGER
EXECUTE LosAngelesCounty.dbo.SDE_get_globals @g_state_id OUTPUT,@g_protected OUTPUT,@g_is_default OUTPUT,@g_version_id OUTPUT,@state_is_set OUTPUT
IF (@g_version_id = -1) AND (@g_is_default = '0')
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END

IF (@g_version_id = -1) AND (@g_is_default = '1') AND (@state_is_set = 1)
BEGIN
  RAISERROR ('Cannot call set_current_version before editing default version. Call set_default before editing.',16,-1)
  RETURN
END

IF @g_version_id != -1  -- standard editing
BEGIN
  EXECUTE @ret = LosAngelesCounty.dbo.SDE_current_version_writable @current_state OUTPUT
  IF @ret <> 0 RETURN
END
IF @g_version_id = -1
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END
DECLARE @row_id INTEGER
DECLARE @old_state_id BIGINT
DECLARE @new_state BIGINT
DECLARE @current_lineage BIGINT
DECLARE @spatial_column INTEGER
DECLARE @edit_cnt INTEGER
DECLARE @error_string NVARCHAR(256)

SELECT @current_lineage = lineage_name  FROM LosAngelesCounty.dbo.SDE_states
  WHERE state_id = @current_state
DECLARE del_cursor CURSOR FOR SELECT OBJECTID,SDE_STATE_ID FROM deleted
OPEN del_cursor
FETCH NEXT FROM del_cursor INTO @row_id, @old_state_id
WHILE @@FETCH_STATUS = 0
BEGIN
  IF @g_is_default = '0'
  BEGIN
    IF (@old_state_id != @current_state)
      INSERT INTO LOSANGELESCOUNTY.DBO.d28 VALUES (@old_state_id,@row_id,@current_state)
    ELSE
    BEGIN
      DELETE FROM LOSANGELESCOUNTY.DBO.a28 WHERE OBJECTID = @row_id AND SDE_STATE_ID = @current_state
      DELETE FROM LOSANGELESCOUNTY.DBO.SDE_GEOMETRY23 WHERE GEOMETRY_ID = @row_id AND SDE_STATE_ID = @current_state
    END
  END
  FETCH NEXT FROM del_cursor INTO @row_id, @old_state_id
END
CLOSE del_cursor
DEALLOCATE del_cursor
IF (SELECT COUNT (*) FROM LosAngelesCounty.dbo.SDE_mvtables_modified WHERE state_id = @current_state AND registration_id = 28) = 0
 AND @current_state > 0
EXECUTE LosAngelesCounty.dbo.SDE_mvmodified_table_insert 28, @current_state
END
go

