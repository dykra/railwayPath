CREATE VIEW DBO.CAMS_ADDRESS_LINES_evw AS SELECT b.OBJECTID + 0 OBJECTID,b.FullName,b.Type,b.Elevation,b.Surface,b.Status,b.DrivingDir,b.From_L,b.From_R,b.To_L,b.To_R,b.Parity_L,b.Parity_R,b.StPreDir,b.StPreMod,b.StPreType,b.StArticle,b.StName,b.StPostType,b.StPostDir,b.StPostMod,b.Zip_L,b.Zip_R,b.LCity_L,b.LCity_R,b.NameCat_L,b.NameCat_R,b.Accuracy,b.Jurisdiction,b.Source,b.SourceID,b.UpdateDate,b.Shape,b.OBJECTID - b.OBJECTID SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.CAMS_ADDRESS_LINES b LEFT HASH JOIN  (SELECT SDE_DELETES_ROW_ID,SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.d28 WHERE SDE_STATE_ID = 0 AND DELETED_AT IN (SELECT l.lineage_id FROM LosAngelesCounty.dbo.SDE_states s INNER LOOP JOIN LosAngelesCounty.dbo.SDE_state_lineages l ON l.lineage_name = s.lineage_name WHERE s.state_id = LosAngelesCounty.dbo.SDE_get_view_state() AND l.lineage_id <= s.state_id ) ) d ON b.OBJECTID = d.SDE_DELETES_ROW_ID WHERE d.SDE_STATE_ID IS NULL UNION ALL SELECT a.OBJECTID + 0 OBJECTID,a.FullName,a.Type,a.Elevation,a.Surface,a.Status,a.DrivingDir,a.From_L,a.From_R,a.To_L,a.To_R,a.Parity_L,a.Parity_R,a.StPreDir,a.StPreMod,a.StPreType,a.StArticle,a.StName,a.StPostType,a.StPostDir,a.StPostMod,a.Zip_L,a.Zip_R,a.LCity_L,a.LCity_R,a.NameCat_L,a.NameCat_R,a.Accuracy,a.Jurisdiction,a.Source,a.SourceID,a.UpdateDate,a.Shape,a.SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.a28 a LEFT HASH JOIN (SELECT SDE_DELETES_ROW_ID,SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.d28 WHERE DELETED_AT IN (SELECT l.lineage_id FROM LosAngelesCounty.dbo.SDE_states s INNER LOOP JOIN LosAngelesCounty.dbo.SDE_state_lineages l ON l.lineage_name = s.lineage_name WHERE s.state_id = LosAngelesCounty.dbo.SDE_get_view_state() AND l.lineage_id <= s.state_id ) ) d ON (a.OBJECTID = d.SDE_DELETES_ROW_ID) AND  (a.SDE_STATE_ID = d.SDE_STATE_ID) WHERE a.SDE_STATE_ID IN (SELECT l.lineage_id FROM LosAngelesCounty.dbo.SDE_states s INNER LOOP JOIN LosAngelesCounty.dbo.SDE_state_lineages l ON l.lineage_name = s.lineage_name WHERE s.state_id = LosAngelesCounty.dbo.SDE_get_view_state() AND l.lineage_id <= s.state_id ) AND d.SDE_STATE_ID IS NULL
go

-- No source code for LosAngelesCounty.dbo.CAMS_ADDRESS_LINES_evw.v28_insert
go

-- No source code for LosAngelesCounty.dbo.CAMS_ADDRESS_LINES_evw.v28_delete
go

-- No source code for LosAngelesCounty.dbo.CAMS_ADDRESS_LINES_evw.v28_update
go

