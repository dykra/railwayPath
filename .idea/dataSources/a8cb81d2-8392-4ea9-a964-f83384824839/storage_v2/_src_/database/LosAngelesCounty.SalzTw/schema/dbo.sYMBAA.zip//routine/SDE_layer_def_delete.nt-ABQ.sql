CREATE PROCEDURE dbo.SDE_layer_def_delete               @layer_idVal INTEGER AS SET NOCOUNT ON             DELETE FROM LosAngelesCounty.dbo.SDE_layers WHERE layer_id = @layer_idVal
go

