CREATE PROCEDURE dbo.SDE_archives_def_delete
@archivingRegIdVal INTEGER AS SET NOCOUNT ON
BEGIN
DELETE FROM LosAngelesCounty.dbo.SDE_archives WHERE archiving_regid =  @archivingRegIdVal
END
go

