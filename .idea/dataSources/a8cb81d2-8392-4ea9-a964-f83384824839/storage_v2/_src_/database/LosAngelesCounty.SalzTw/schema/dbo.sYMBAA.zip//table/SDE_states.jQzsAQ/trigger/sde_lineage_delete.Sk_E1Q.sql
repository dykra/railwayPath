CREATE TRIGGER sde_lineage_delete ON LosAngelesCounty.dbo.SDE_states FOR DELETE AS      DELETE FROM LosAngelesCounty.dbo.SDE_state_lineages WHERE lineage_id IN (SELECT state_id FROM deleted)
go

