CREATE PROCEDURE dbo.SDE_locator_def_delete @id1        INTEGER AS SET NOCOUNT ON DELETE FROM LosAngelesCounty.dbo.SDE_locators WHERE locator_id = @id1
go

