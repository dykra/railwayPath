CREATE PROCEDURE dbo.SDE_sref_def_delete       @sridVal INTEGER AS SET NOCOUNT ON DELETE FROM LosAngelesCounty.dbo.SDE_spatial_references WHERE srid = @sridVal
go

