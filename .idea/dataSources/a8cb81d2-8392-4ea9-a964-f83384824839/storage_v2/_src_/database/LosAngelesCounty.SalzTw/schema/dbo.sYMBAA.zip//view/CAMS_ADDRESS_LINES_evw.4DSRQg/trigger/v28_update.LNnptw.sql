CREATE TRIGGER DBO.v28_update  ON LOSANGELESCOUNTY.DBO.CAMS_ADDRESS_LINES_evw INSTEAD OF UPDATE AS 
BEGIN
IF @@rowcount = 0 RETURN
DECLARE @current_state BIGINT
DECLARE @ret INTEGER
-- Check if we are already in an edit session.
DECLARE @g_state_id BIGINT
DECLARE @g_protected CHAR(1)
DECLARE @g_is_default CHAR(1)
DECLARE @g_version_id INTEGER
DECLARE @state_is_set INTEGER
EXECUTE LosAngelesCounty.dbo.SDE_get_globals @g_state_id OUTPUT,@g_protected OUTPUT,@g_is_default OUTPUT,@g_version_id OUTPUT,@state_is_set OUTPUT
IF (@g_version_id = -1) AND (@g_is_default = '0')
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END

IF (@g_version_id = -1) AND (@g_is_default = '1') AND (@state_is_set = 1)
BEGIN
  RAISERROR ('Cannot call set_current_version before editing default version. Call set_default before editing.',16,-1)
  RETURN
END

IF @g_version_id = -1
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END
IF @g_version_id != -1  -- standard editing
BEGIN
  EXECUTE @ret = LosAngelesCounty.dbo.SDE_current_version_writable @current_state OUTPUT
  IF @ret <> 0 RETURN
END
ELSE -- default version editing
  SET @current_state = @g_state_id
DECLARE @new_state BIGINT
DECLARE @current_lineage BIGINT
DECLARE @edit_cnt INTEGER
DECLARE @error_string NVARCHAR(256)

SELECT @current_lineage = lineage_name  FROM LosAngelesCounty.dbo.SDE_states
  WHERE state_id = @current_state
IF UPDATE(OBJECTID)
BEGIN
  DECLARE @row_count INTEGER
  SELECT @row_count = COUNT(*) FROM deleted
  IF @row_count > 1 OR (SELECT COUNT(*) FROM inserted i INNER JOIN deleted d
  ON i.OBJECTID = d.OBJECTID) != @row_count
  BEGIN
    RAISERROR ('Attempted update of SDE row id column.',16,-1)
    RETURN
  END
END
DECLARE @new_row_id INTEGER
DECLARE @old_row_id INTEGER
DECLARE @old_state_id BIGINT
DECLARE @new_spatial_column geometry
DECLARE @old_spatial_column geometry
DECLARE updt_cursor CURSOR FOR SELECT d.OBJECTID,d.SDE_STATE_ID,i.SHAPE,d.SHAPE,
 i.OBJECTID,
 i.FullName,
 i.Type,
 i.Elevation,
 i.Surface,
 i.Status,
 i.DrivingDir,
 i.From_L,
 i.From_R,
 i.To_L,
 i.To_R,
 i.Parity_L,
 i.Parity_R,
 i.StPreDir,
 i.StPreMod,
 i.StPreType,
 i.StArticle,
 i.StName,
 i.StPostType,
 i.StPostDir,
 i.StPostMod,
 i.Zip_L,
 i.Zip_R,
 i.LCity_L,
 i.LCity_R,
 i.NameCat_L,
 i.NameCat_R,
 i.Accuracy,
 i.Jurisdiction,
 i.Source,
 i.SourceID,
 i.UpdateDate
  FROM inserted i INNER JOIN deleted d
  ON i.OBJECTID = d.OBJECTID
DECLARE @upd_OBJECTID int
DECLARE @upd_FullName nvarchar(255) 
DECLARE @upd_Type nvarchar(40) 
DECLARE @upd_Elevation nvarchar(30) 
DECLARE @upd_Surface nvarchar(15) 
DECLARE @upd_Status nvarchar(25) 
DECLARE @upd_DrivingDir nvarchar(30) 
DECLARE @upd_From_L int
DECLARE @upd_From_R int
DECLARE @upd_To_L int
DECLARE @upd_To_R int
DECLARE @upd_Parity_L nvarchar(7) 
DECLARE @upd_Parity_R nvarchar(7) 
DECLARE @upd_StPreDir nvarchar(2) 
DECLARE @upd_StPreMod nvarchar(15) 
DECLARE @upd_StPreType nvarchar(50) 
DECLARE @upd_StArticle nvarchar(10) 
DECLARE @upd_StName nvarchar(50) 
DECLARE @upd_StPostType nvarchar(50) 
DECLARE @upd_StPostDir nvarchar(2) 
DECLARE @upd_StPostMod nvarchar(15) 
DECLARE @upd_Zip_L nvarchar(5) 
DECLARE @upd_Zip_R nvarchar(5) 
DECLARE @upd_LCity_L nvarchar(30) 
DECLARE @upd_LCity_R nvarchar(30) 
DECLARE @upd_NameCat_L nvarchar(10) 
DECLARE @upd_NameCat_R nvarchar(10) 
DECLARE @upd_Accuracy numeric(38,8) 
DECLARE @upd_Jurisdiction nvarchar(10) 
DECLARE @upd_Source nvarchar(20) 
DECLARE @upd_SourceID nvarchar(50) 
DECLARE @upd_UpdateDate datetime2
OPEN updt_cursor
FETCH NEXT FROM updt_cursor INTO @old_row_id, @old_state_id, @new_spatial_column, @old_spatial_column, @upd_OBJECTID, @upd_FullName, @upd_Type, @upd_Elevation, @upd_Surface, @upd_Status, @upd_DrivingDir, @upd_From_L, @upd_From_R, @upd_To_L, @upd_To_R, @upd_Parity_L, @upd_Parity_R, @upd_StPreDir, @upd_StPreMod, @upd_StPreType, @upd_StArticle, @upd_StName, @upd_StPostType, @upd_StPostDir, @upd_StPostMod, @upd_Zip_L, @upd_Zip_R, @upd_LCity_L, @upd_LCity_R, @upd_NameCat_L, @upd_NameCat_R, @upd_Accuracy, @upd_Jurisdiction, @upd_Source, @upd_SourceID, @upd_UpdateDate
WHILE @@FETCH_STATUS = 0
BEGIN
  IF @g_is_default = '0'
  BEGIN
    IF (@old_state_id != @current_state)
    BEGIN
     INSERT INTO LOSANGELESCOUNTY.DBO.a28 (
OBJECTID,FullName,Type,Elevation,Surface,Status,DrivingDir,From_L,From_R,To_L,To_R,Parity_L,Parity_R,StPreDir,StPreMod,StPreType,StArticle,StName,StPostType,StPostDir,StPostMod,Zip_L,Zip_R,LCity_L,LCity_R,NameCat_L,NameCat_R,Accuracy,Jurisdiction,Source,SourceID,UpdateDate,Shape,SDE_STATE_ID)
        VALUES(  @upd_OBJECTID, @upd_FullName, @upd_Type, @upd_Elevation, @upd_Surface, @upd_Status, @upd_DrivingDir, @upd_From_L, @upd_From_R, @upd_To_L, @upd_To_R, @upd_Parity_L, @upd_Parity_R, @upd_StPreDir, @upd_StPreMod, @upd_StPreType, @upd_StArticle, @upd_StName, @upd_StPostType, @upd_StPostDir, @upd_StPostMod, @upd_Zip_L, @upd_Zip_R, @upd_LCity_L, @upd_LCity_R, @upd_NameCat_L, @upd_NameCat_R, @upd_Accuracy, @upd_Jurisdiction, @upd_Source, @upd_SourceID, @upd_UpdateDate, @new_spatial_column, @current_state)

     INSERT INTO LOSANGELESCOUNTY.DBO.d28 VALUES (@old_state_id, @old_row_id, @current_state)
     IF @old_spatial_column IS NOT NULL
     BEGIN
       IF NOT UPDATE(SHAPE)
         INSERT INTO LOSANGELESCOUNTY.DBO.SDE_GEOMETRY23 (GEOMETRY_ID, CAD, SDE_STATE_ID) SELECT GEOMETRY_ID, 
 CAD, @current_state FROM LOSANGELESCOUNTY.DBO.SDE_GEOMETRY23 WHERE GEOMETRY_ID = @old_row_id and SDE_STATE_ID = @old_state_id
     END
    END
    ELSE
    BEGIN
     UPDATE LOSANGELESCOUNTY.DBO.a28 SET FullName = @upd_FullName,Type = @upd_Type,Elevation = @upd_Elevation,Surface = @upd_Surface,Status = @upd_Status,DrivingDir = @upd_DrivingDir,From_L = @upd_From_L,From_R = @upd_From_R,To_L = @upd_To_L,To_R = @upd_To_R,Parity_L = @upd_Parity_L,Parity_R = @upd_Parity_R,StPreDir = @upd_StPreDir,StPreMod = @upd_StPreMod,StPreType = @upd_StPreType,StArticle = @upd_StArticle,StName = @upd_StName,StPostType = @upd_StPostType,StPostDir = @upd_StPostDir,StPostMod = @upd_StPostMod,Zip_L = @upd_Zip_L,Zip_R = @upd_Zip_R,LCity_L = @upd_LCity_L,LCity_R = @upd_LCity_R,NameCat_L = @upd_NameCat_L,NameCat_R = @upd_NameCat_R,Accuracy = @upd_Accuracy,Jurisdiction = @upd_Jurisdiction,Source = @upd_Source,SourceID = @upd_SourceID,UpdateDate = @upd_UpdateDate,Shape = @new_spatial_column 
WHERE OBJECTID = @old_row_id  AND SDE_STATE_ID = @current_state
     IF @old_spatial_column IS NOT NULL
     BEGIN
       IF UPDATE(SHAPE) 
         DELETE FROM LOSANGELESCOUNTY.DBO.SDE_GEOMETRY23 WHERE GEOMETRY_ID = @old_row_id  AND SDE_STATE_ID = @current_state
     END
    END
  END
FETCH NEXT FROM updt_cursor INTO @old_row_id, @old_state_id, @new_spatial_column, @old_spatial_column, @upd_OBJECTID, @upd_FullName, @upd_Type, @upd_Elevation, @upd_Surface, @upd_Status, @upd_DrivingDir, @upd_From_L, @upd_From_R, @upd_To_L, @upd_To_R, @upd_Parity_L, @upd_Parity_R, @upd_StPreDir, @upd_StPreMod, @upd_StPreType, @upd_StArticle, @upd_StName, @upd_StPostType, @upd_StPostDir, @upd_StPostMod, @upd_Zip_L, @upd_Zip_R, @upd_LCity_L, @upd_LCity_R, @upd_NameCat_L, @upd_NameCat_R, @upd_Accuracy, @upd_Jurisdiction, @upd_Source, @upd_SourceID, @upd_UpdateDate
END
CLOSE updt_cursor
DEALLOCATE updt_cursor
IF (SELECT COUNT (*) FROM LosAngelesCounty.dbo.SDE_mvtables_modified WHERE state_id = @current_state AND registration_id = 28) = 0
 AND @current_state > 0
  EXECUTE LosAngelesCounty.dbo.SDE_mvmodified_table_insert 28, @current_state
END
go

