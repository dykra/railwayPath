CREATE PROCEDURE dbo.SDE_table_lock_def_delete_user @sdeIdVal INTEGER AS SET NOCOUNT ON     BEGIN TRAN table_lock_tran     DELETE FROM LosAngelesCounty.dbo.SDE_table_locks WHERE  sde_id = @sdeIdVal     COMMIT TRAN table_lock_tran
go

