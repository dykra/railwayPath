CREATE PROCEDURE dbo.SDE_generator_release AS SELECT 3 FROM LosAngelesCounty.dbo.SDE_version
go

