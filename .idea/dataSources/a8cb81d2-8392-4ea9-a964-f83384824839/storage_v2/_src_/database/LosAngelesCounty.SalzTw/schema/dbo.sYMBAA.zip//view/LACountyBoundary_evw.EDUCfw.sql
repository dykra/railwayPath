CREATE VIEW DBO.LACountyBoundary_evw AS SELECT b.OBJECTID + 0 OBJECTID,b.CITY,b.CITY_ID,b.CITY_TYPE,b.CITY_NAME,b.CITY_LABEL,b.COLOR_CODE,b.ABBR,b.CITY_NO,b.DESCRIPTN,b.URL,b.PHONE,b.OF_AREA_SM,b.FEAT_TYPE,b.COMMENT,b.SUB_TYPE,b.COLOR,b.SQMI,b.Shape,b.County,b.OBJECTID - b.OBJECTID SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.LACOUNTYBOUNDARY b LEFT HASH JOIN  (SELECT SDE_DELETES_ROW_ID,SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.d31 WHERE SDE_STATE_ID = 0 AND DELETED_AT IN (SELECT l.lineage_id FROM LosAngelesCounty.dbo.SDE_states s INNER LOOP JOIN LosAngelesCounty.dbo.SDE_state_lineages l ON l.lineage_name = s.lineage_name WHERE s.state_id = LosAngelesCounty.dbo.SDE_get_view_state() AND l.lineage_id <= s.state_id ) ) d ON b.OBJECTID = d.SDE_DELETES_ROW_ID WHERE d.SDE_STATE_ID IS NULL UNION ALL SELECT a.OBJECTID + 0 OBJECTID,a.CITY,a.CITY_ID,a.CITY_TYPE,a.CITY_NAME,a.CITY_LABEL,a.COLOR_CODE,a.ABBR,a.CITY_NO,a.DESCRIPTN,a.URL,a.PHONE,a.OF_AREA_SM,a.FEAT_TYPE,a.COMMENT,a.SUB_TYPE,a.COLOR,a.SQMI,a.Shape,a.County,a.SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.a31 a LEFT HASH JOIN (SELECT SDE_DELETES_ROW_ID,SDE_STATE_ID FROM LOSANGELESCOUNTY.DBO.d31 WHERE DELETED_AT IN (SELECT l.lineage_id FROM LosAngelesCounty.dbo.SDE_states s INNER LOOP JOIN LosAngelesCounty.dbo.SDE_state_lineages l ON l.lineage_name = s.lineage_name WHERE s.state_id = LosAngelesCounty.dbo.SDE_get_view_state() AND l.lineage_id <= s.state_id ) ) d ON (a.OBJECTID = d.SDE_DELETES_ROW_ID) AND  (a.SDE_STATE_ID = d.SDE_STATE_ID) WHERE a.SDE_STATE_ID IN (SELECT l.lineage_id FROM LosAngelesCounty.dbo.SDE_states s INNER LOOP JOIN LosAngelesCounty.dbo.SDE_state_lineages l ON l.lineage_name = s.lineage_name WHERE s.state_id = LosAngelesCounty.dbo.SDE_get_view_state() AND l.lineage_id <= s.state_id ) AND d.SDE_STATE_ID IS NULL
go

-- No source code for LosAngelesCounty.dbo.LACountyBoundary_evw.v31_insert
go

-- No source code for LosAngelesCounty.dbo.LACountyBoundary_evw.v31_delete
go

-- No source code for LosAngelesCounty.dbo.LACountyBoundary_evw.v31_update
go

