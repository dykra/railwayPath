create view dbo.dbtune as select * from LosAngelesCounty.dbo.SDE_dbtune
go

