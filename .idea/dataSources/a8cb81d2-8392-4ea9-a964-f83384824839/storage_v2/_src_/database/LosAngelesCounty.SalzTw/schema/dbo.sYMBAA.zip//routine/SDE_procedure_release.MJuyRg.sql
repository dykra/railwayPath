CREATE PROCEDURE dbo.SDE_procedure_release AS SELECT 6000105 FROM LosAngelesCounty.dbo.SDE_version
go

