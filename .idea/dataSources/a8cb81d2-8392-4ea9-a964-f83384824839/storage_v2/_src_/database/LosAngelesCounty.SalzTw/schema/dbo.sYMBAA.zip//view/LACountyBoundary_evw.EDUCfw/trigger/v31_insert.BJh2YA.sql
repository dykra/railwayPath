CREATE TRIGGER DBO.v31_insert ON LOSANGELESCOUNTY.DBO.LACountyBoundary_evw INSTEAD OF INSERT AS 
BEGIN
DECLARE @rowcount INTEGER
SET @rowcount = @@rowcount
IF @rowcount = 0 RETURN
-- Check if we are already in an edit session.
DECLARE @g_state_id BIGINT
DECLARE @g_protected CHAR(1)
DECLARE @g_is_default CHAR(1)
DECLARE @g_version_id INTEGER
DECLARE @state_is_set INTEGER
EXECUTE LosAngelesCounty.dbo.SDE_get_globals @g_state_id OUTPUT,@g_protected OUTPUT,@g_is_default OUTPUT,@g_version_id OUTPUT,@state_is_set OUTPUT
IF (@g_version_id = -1) AND (@g_is_default = '0')
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END

IF (@g_version_id = -1) AND (@g_is_default = '1') AND (@state_is_set = 1)
BEGIN
  RAISERROR ('Cannot call set_current_version before editing default version. Call set_default before editing.',16,-1)
  RETURN
END

IF @g_version_id = -1
BEGIN
  RAISERROR ('User must call edit_version before editing the view.',16,-1)
  RETURN
END
DECLARE @ret INTEGER
DECLARE @current_state BIGINT
IF @g_version_id != -1  -- standard editing
BEGIN
  EXECUTE @ret = LosAngelesCounty.dbo.SDE_current_version_writable @current_state OUTPUT
  IF @ret <> 0 RETURN
END
ELSE -- default version editing
  SET @current_state = @g_state_id
DECLARE @next_row_id INTEGER
DECLARE @num_ids INTEGER
DECLARE @return_row_id INTEGER
DECLARE @num_return_ids INTEGER
DECLARE @archive_oid INTEGER
IF @rowcount = 1
BEGIN
  SELECT @next_row_id = OBJECTID FROM inserted
    IF (@next_row_id IS NULL)
    BEGIN
    EXECUTE LOSANGELESCOUNTY.DBO.i31_get_ids 2, 1, @next_row_id OUTPUT, @num_ids OUTPUT
    IF @num_ids > 1
    BEGIN
      SET @return_row_id = @next_row_id + 1
      SET @num_return_ids = @num_ids - 1
      EXECUTE LOSANGELESCOUNTY.DBO.i31_return_ids 2, @return_row_id, @num_return_ids
    END
  END

  -- If editing state 0, then the insert being performed
  -- must be written to the base table, not the adds table

  IF @current_state = 0
  BEGIN
  INSERT INTO LOSANGELESCOUNTY.DBO.LACOUNTYBOUNDARY
  (OBJECTID,CITY,CITY_ID,CITY_TYPE,CITY_NAME,CITY_LABEL,COLOR_CODE,ABBR,CITY_NO,DESCRIPTN,URL,PHONE,OF_AREA_SM,FEAT_TYPE,COMMENT,SUB_TYPE,COLOR,SQMI,Shape,County)
  SELECT 
  @next_row_id,i.CITY,i.CITY_ID,i.CITY_TYPE,i.CITY_NAME,i.CITY_LABEL,i.COLOR_CODE,i.ABBR,i.CITY_NO,i.DESCRIPTN,i.URL,i.PHONE,i.OF_AREA_SM,i.FEAT_TYPE,i.COMMENT,i.SUB_TYPE,i.COLOR,i.SQMI,i.Shape,i.County  FROM inserted i
  END
  ELSE
  BEGIN
  INSERT INTO LOSANGELESCOUNTY.DBO.a31
  (OBJECTID,CITY,CITY_ID,CITY_TYPE,CITY_NAME,CITY_LABEL,COLOR_CODE,ABBR,CITY_NO,DESCRIPTN,URL,PHONE,OF_AREA_SM,FEAT_TYPE,COMMENT,SUB_TYPE,COLOR,SQMI,Shape,County,SDE_STATE_ID)
  SELECT 
  @next_row_id,i.CITY,i.CITY_ID,i.CITY_TYPE,i.CITY_NAME,i.CITY_LABEL,i.COLOR_CODE,i.ABBR,i.CITY_NO,i.DESCRIPTN,i.URL,i.PHONE,i.OF_AREA_SM,i.FEAT_TYPE,i.COMMENT,i.SUB_TYPE,i.COLOR,i.SQMI,i.Shape,i.County,@current_state  FROM inserted i
  END
END
ELSE
BEGIN
  --Multi-row insert, need to cursor through the changes.
  DECLARE ins_cursor CURSOR FOR
  SELECT OBJECTID,CITY,CITY_ID,CITY_TYPE,CITY_NAME,CITY_LABEL,COLOR_CODE,ABBR,CITY_NO,DESCRIPTN,URL,PHONE,OF_AREA_SM,FEAT_TYPE,COMMENT,SUB_TYPE,COLOR,SQMI,Shape,County,SDE_STATE_ID
  FROM inserted
  DECLARE @col1 int
  DECLARE @col2 int
  DECLARE @col3 int
  DECLARE @col4 nvarchar(25) 
  DECLARE @col5 nvarchar(25) 
  DECLARE @col6 nvarchar(21) 
  DECLARE @col7 smallint
  DECLARE @col8 nvarchar(4) 
  DECLARE @col9 smallint
  DECLARE @col10 nvarchar(8) 
  DECLARE @col11 nvarchar(50) 
  DECLARE @col12 nvarchar(50) 
  DECLARE @col13 numeric(18,8) 
  DECLARE @col14 nvarchar(16) 
  DECLARE @col15 nvarchar(50) 
  DECLARE @col16 smallint
  DECLARE @col17 nvarchar(16) 
  DECLARE @col18 numeric(38,8) 
  DECLARE @col19 geometry
  DECLARE @col20 nvarchar(50) 
  DECLARE @col21 bigint
  OPEN ins_cursor
  FETCH NEXT FROM ins_cursor INTO @col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21
  WHILE @@FETCH_STATUS = 0
  BEGIN
    EXECUTE LOSANGELESCOUNTY.DBO.i31_get_ids 2, 1, @next_row_id OUTPUT, @num_ids OUTPUT
    IF @num_ids > 1
    BEGIN
      SET @return_row_id = @next_row_id + 1
      SET @num_return_ids = @num_ids - 1
      EXECUTE LOSANGELESCOUNTY.DBO.i31_return_ids 2, @return_row_id, @num_return_ids
    END
    IF @current_state = 0
    BEGIN
      -- If editing state 0, then the insert being performed
      -- must be written to the base table, not the adds table

      INSERT INTO LOSANGELESCOUNTY.DBO.LACOUNTYBOUNDARY
      (OBJECTID,CITY,CITY_ID,CITY_TYPE,CITY_NAME,CITY_LABEL,COLOR_CODE,ABBR,CITY_NO,DESCRIPTN,URL,PHONE,OF_AREA_SM,FEAT_TYPE,COMMENT,SUB_TYPE,COLOR,SQMI,Shape,County)
      VALUES (@next_row_id,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20 )
    END
    ELSE
    BEGIN
      INSERT INTO LOSANGELESCOUNTY.DBO.a31
      (OBJECTID,CITY,CITY_ID,CITY_TYPE,CITY_NAME,CITY_LABEL,COLOR_CODE,ABBR,CITY_NO,DESCRIPTN,URL,PHONE,OF_AREA_SM,FEAT_TYPE,COMMENT,SUB_TYPE,COLOR,SQMI,Shape,County,SDE_STATE_ID)
      VALUES (@next_row_id,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@current_state )
    END

    FETCH NEXT FROM ins_cursor INTO @col1,@col2,@col3,@col4,@col5,@col6,@col7,@col8,@col9,@col10,@col11,@col12,@col13,@col14,@col15,@col16,@col17,@col18,@col19,@col20,@col21
  END
  CLOSE ins_cursor
  DEALLOCATE ins_cursor
END
IF (SELECT COUNT (*) FROM LosAngelesCounty.dbo.SDE_mvtables_modified WHERE state_id = @current_state AND registration_id = 31) = 0
 AND @current_state > 0
EXECUTE LosAngelesCounty.dbo.SDE_mvmodified_table_insert 31, @current_state
END
go

